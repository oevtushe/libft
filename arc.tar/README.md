# mylib
Useful functions C
Mylib
